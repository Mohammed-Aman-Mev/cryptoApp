import Chart2 from "../Charts/Chart2";

const Detailes = () => {
  return (
    <div className="flex items-center flex-col h-auto">
      <h1>hello</h1>
      <div className="w-[400px] text-red-300">
        <Chart2 />
      </div>
      <div className="w-[400px] text-red-300"></div>
    </div>
  );
};

export default Detailes;
